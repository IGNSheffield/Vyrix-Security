package me.yolosanta.vyrix.database;

import com.mongodb.MongoClient;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import lombok.Getter;
import me.yolosanta.vyrix.VyrixSecurity;
import org.bson.Document;

import java.util.Arrays;

@Getter
public class MongoHandler {

    private MongoClient mongoClient;
    private MongoDatabase mongoDatabase;
    private MongoCollection<Document> mongoCollection;

    private String host;
    private int port;

    private String username;
    private String database;
    private char[] password;

    private boolean online = false;

    public MongoHandler(String host, int port, String username, String database, char[] password) {
        this.host = host;
        this.port = port;
        this.username = username;
        this.database = database;
        this.password = password;
    }

    public void connectWithCredentials() {
        try {
            MongoCredential credentials = MongoCredential.createCredential(username, database, password);

            mongoClient = new MongoClient(new ServerAddress(host, port), Arrays.asList(credentials));

            mongoDatabase = mongoClient.getDatabase(VyrixSecurity.getVyrixSecurity().getConfig().getString("Mongo.Database"));

            mongoCollection = mongoDatabase.getCollection("VyrixSecurity");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void connect() {
        try {
            mongoClient = new MongoClient(host, port);

            mongoDatabase = mongoClient.getDatabase(VyrixSecurity.getVyrixSecurity().getConfig().getString("Mongo.Database"));

            mongoCollection = mongoDatabase.getCollection("VyrixSecurity");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void disconnect() {
        if (mongoClient != null) mongoClient.close();
        mongoClient = null;
        online = false;
    }

    public boolean isOnline() {
        try {
            mongoClient.getAddress();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}