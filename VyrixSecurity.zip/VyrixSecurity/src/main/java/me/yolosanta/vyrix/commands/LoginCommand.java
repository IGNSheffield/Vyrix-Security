package me.yolosanta.vyrix.commands;

import me.yolosanta.vyrix.VyrixSecurity;
import me.yolosanta.vyrix.utils.Encryption;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.defaults.BukkitCommand;
import org.bukkit.entity.Player;

public class LoginCommand extends BukkitCommand {

    public LoginCommand(String name) {
        super(name);
        setUsage("&cUsage: /login <password>");
        setPermission("vyrixsecurity.staff");
    }

    @Override
    public boolean execute(CommandSender sender, String label, String[] args) {
        if (!(sender instanceof Player)) return true;
        Player p = (Player) sender;
        if (!testPermission(p)) return true;
        if (!VyrixSecurity.getVyrixSecurity().getNeedsAuth().contains(p.getUniqueId())) {
            p.sendMessage(ChatColor.RED + "You are already logged in.");
            return true;
        }
        if (args.length == 0) {
            p.sendMessage(ChatColor.translateAlternateColorCodes('&', getUsage()));
            return true;
        }
        if (!VyrixSecurity.getVyrixSecurity().getPlayerHandler().correctLogin(p.getUniqueId(), args[0])) {
            p.sendMessage(ChatColor.RED + "Incorrect Login.");
            return true;
        } else {
            VyrixSecurity.getVyrixSecurity().getNeedsAuth().remove(p.getUniqueId());
            VyrixSecurity.getVyrixSecurity().getPlayerHandler().updateIP(p.getUniqueId(), Encryption.encrypt(p.getAddress().getHostName(), "VyrixUSKey"));
            p.sendMessage(ChatColor.GREEN + "You have been authenticated successfully.");
        }
        return true;
    }
}
