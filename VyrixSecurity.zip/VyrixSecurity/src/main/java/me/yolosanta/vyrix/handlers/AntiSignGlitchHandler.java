package me.yolosanta.vyrix.handlers;

import me.yolosanta.vyrix.VyrixSecurity;
import org.bukkit.ChatColor;
import org.bukkit.block.Sign;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.ArrayList;
import java.util.UUID;


public class AntiSignGlitchHandler implements Listener {

    private final ArrayList<UUID> cacheList = new ArrayList<>();

    @EventHandler(priority = EventPriority.LOWEST)
    public void onBreak(BlockBreakEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();
        if (cacheList.contains(uuid)) return;

        cacheList.add(uuid);

        new BukkitRunnable() {
            @Override
            public void run() {
                cacheList.remove(uuid);
            }
        }.runTaskLaterAsynchronously(VyrixSecurity.getVyrixSecurity(), 20);
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onClick(PlayerInteractEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();
        if (event.getAction() == Action.RIGHT_CLICK_BLOCK && event.getClickedBlock().getState() instanceof Sign) {
            if (cacheList.contains(uuid)) {
                event.setCancelled(true);
                event.getPlayer().sendMessage(ChatColor.RED + "We've detected a sign glitch so prevented it.");
            }
        }
    }
}
