package me.yolosanta.vyrix.handlers;

import me.yolosanta.vyrix.VyrixSecurity;
import me.yolosanta.vyrix.database.PlayerHandler;
import me.yolosanta.vyrix.utils.Encryption;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.*;

public class StaffAuthHandler implements Listener {

    private PlayerHandler playerHandler = VyrixSecurity.getVyrixSecurity().getPlayerHandler();

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (!player.hasPermission("vyrixsecurity.staff")) return;
        VyrixSecurity.getVyrixSecurity().getNeedsAuth().add(player.getUniqueId());
        if (!playerHandler.inDatebase(player.getUniqueId())) {
            for (String msg : VyrixSecurity.getVyrixSecurity().getConfig().getStringList("Modules.Staff-Auth.No-Account-Message")) {
                player.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
            }
        }
        if (playerHandler.inDatebase(player.getUniqueId())) {
            if (Encryption.decrypt((String) playerHandler.getPlayer(player.getUniqueId()).get("lastip"), "VyrixUSKey").equals(player.getAddress().getHostName())) {
                VyrixSecurity.getVyrixSecurity().getNeedsAuth().remove(player.getUniqueId());
                player.sendMessage(ChatColor.GREEN + "You have been auto authenticated.");
            }
        }
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (!player.hasPermission("vyrixsecurity.staff")) return;
        if (event.getFrom().getBlockX() != event.getTo().getBlockX() || event.getFrom().getBlockZ() != event.getTo().getBlockZ()) {
            if (!playerHandler.inDatebase(player.getUniqueId())) {
                player.teleport(event.getFrom());
                for (String msg : VyrixSecurity.getVyrixSecurity().getConfig().getStringList("Modules.Staff-Auth.No-Account-Message")) {
                    player.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
                }
            } else {
                if (VyrixSecurity.getVyrixSecurity().getNeedsAuth().contains(player.getUniqueId())) {
                    player.teleport(event.getFrom());
                    for (String msg : VyrixSecurity.getVyrixSecurity().getConfig().getStringList("Modules.Staff-Auth.Login-Message")) {
                        player.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
                    }
                }
            }
        }
    }

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        if (!player.hasPermission("vyrixsecurity.staff")) return;
        if (!playerHandler.inDatebase(player.getUniqueId())) {
            event.setCancelled(true);
            for (String msg : VyrixSecurity.getVyrixSecurity().getConfig().getStringList("Modules.Staff-Auth.No-Account-Message")) {
                player.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
            }
        }
        if (VyrixSecurity.getVyrixSecurity().getNeedsAuth().contains(player.getUniqueId())) {
            event.setCancelled(true);
            for (String msg : VyrixSecurity.getVyrixSecurity().getConfig().getStringList("Modules.Staff-Auth.Login-Message")) {
                player.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));

            }
        }
    }

    @EventHandler
    public void onCommand(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        if (!player.hasPermission("vyrixsecurity.staff")) return;
        String cmd = event.getMessage();
        String[] args = cmd.split(" ");
        String base = args[0];
        if (!playerHandler.inDatebase(player.getUniqueId())) {
            if (base.equalsIgnoreCase("/register") || base.equalsIgnoreCase("/login")) return;
            for (String msg : VyrixSecurity.getVyrixSecurity().getConfig().getStringList("Modules.Staff-Auth.No-Account-Message")) {
                player.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
            }
            event.setCancelled(true);
        } else {
            if (VyrixSecurity.getVyrixSecurity().getNeedsAuth().contains(player.getUniqueId())) {
                for (String msg : VyrixSecurity.getVyrixSecurity().getConfig().getStringList("Modules.Staff-Auth.Login-Message")) {
                    player.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
                }
                event.setCancelled(true);
            }
        }
    }

    @EventHandler
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        if (!player.hasPermission("vyrixsecurity.staff")) return;
        if (!playerHandler.inDatebase(player.getUniqueId())) {
            event.setCancelled(true);
        } else {
            if (VyrixSecurity.getVyrixSecurity().getNeedsAuth().contains(player.getUniqueId()))
                event.setCancelled(true);
        }
    }

    @EventHandler
    public void onDamage(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player) {
            Player damager = (Player) event.getDamager();
            if (!damager.hasPermission("vyrixsecurity.staff")) return;
            if (!playerHandler.inDatebase(damager.getUniqueId())) {
                event.setCancelled(true);
                for (String msg : VyrixSecurity.getVyrixSecurity().getConfig().getStringList("Modules.Staff-Auth.No-Account-Message")) {
                    damager.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
                }
            }
            if (VyrixSecurity.getVyrixSecurity().getNeedsAuth().contains(damager.getUniqueId())) {
                event.setCancelled(true);
                for (String msg : VyrixSecurity.getVyrixSecurity().getConfig().getStringList("Modules.Staff-Auth.Login-Message")) {
                    damager.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
                }
            }
        }
        if (event.getEntity() instanceof Player) {
            Player damagee = (Player) event.getEntity();
            if (!damagee.hasPermission("vyrixsecurity.staff")) return;
            if (!playerHandler.inDatebase(damagee.getUniqueId())) {
                event.setCancelled(true);
                for (String msg : VyrixSecurity.getVyrixSecurity().getConfig().getStringList("Modules.Staff-Auth.No-Account-Message")) {
                    damagee.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
                }
            }
            if (VyrixSecurity.getVyrixSecurity().getNeedsAuth().contains(damagee.getUniqueId())) {
                event.setCancelled(true);
                for (String msg : VyrixSecurity.getVyrixSecurity().getConfig().getStringList("Modules.Staff-Auth.Login-Message")) {
                    damagee.sendMessage(ChatColor.translateAlternateColorCodes('&', msg));
                }
            }
        }
    }
}
