package me.yolosanta.vyrix;

import lombok.Getter;
import lombok.Setter;
import me.yolosanta.vyrix.database.MongoHandler;
import me.yolosanta.vyrix.database.PlayerHandler;
import me.yolosanta.vyrix.handlers.*;
import me.yolosanta.vyrix.utils.Encryption;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.event.HandlerList;
import org.bukkit.plugin.java.JavaPlugin;

import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.UUID;

@Getter
@Setter
public class VyrixSecurity extends JavaPlugin {

    @Getter
    private static VyrixSecurity vyrixSecurity;

    private boolean underAttack = false;

    private String status;

    private MongoHandler mongoHandler;
    private PlayerHandler playerHandler;
    private AntiTabHandler antiTabHandler;
    private AntiSignGlitchHandler antiSignGlitchHandler;

    private Encryption encryption = new Encryption();

    private ArrayList<UUID> needsAuth = new ArrayList<>();

    @Override
    public void onEnable() {
        vyrixSecurity = this;

        getConfig().options().copyDefaults(true);
        saveConfig();


        print(" ");
        print("&a---------- VyrixSecurity setup started ----------");
        print(" ");

        print("-| &eLoading Anti-Plugin-Tab");
        if (check("Anti-Plugin-Tab")) {
            antiTabHandler = new AntiTabHandler();
        }
        status = check("Anti-Plugin-Tab") ? "&aEnabled" : "&cDisabled";
        print("  " + (char) 175 + " &eStatus: " + status);

        print(" ");
        print("-| &eLoading Console-IP-Hider");
        if (check("Console-IP-Hider")) {
            ((Logger) LogManager.getRootLogger()).addFilter(new FilterHandler());
        }
        status = check("Console-IP-Hider") ? "&aEnabled" : "&cDisabled";
        print("  " + (char) 175 + " &eStatus: " + status);

        print(" ");
        print("-| &eLoading Anti-Book-Exploit");
        if (check("Anti-Book-Exploit")) {
            Bukkit.getServer().getPluginManager().registerEvents(new BookHandler(), this);
        }
        status = check("Anti-Book-Exploit") ? "&aEnabled" : "&cDisabled";
        print("  " + (char) 175 + " &eStatus: " + status);

        print(" ");
        print("-| &eLoading NoOP");
        if (check("NoOP")) {
            Bukkit.getServer().getPluginManager().registerEvents(new NoOPHandler(), this);
        }
        status = check("NoOP") ? "&aEnabled" : "&cDisabled";
        print("  " + (char) 175 + " &eStatus: " + status);

        print(" ");
        print("-| &eLoading NoGrief");
        if (check("NoGrief")) {
            Arrays.asList(
                    new NoGriefHandler(getConfig().getString("Modules.NoGrief.Command"))
            ).forEach(cmd -> new CommandHandler(cmd, cmd.getName()));
            getServer().getPluginManager().registerEvents(new NoGriefHandler(null), this);
        }
        status = check("NoGrief") ? "&aEnabled" : "&cDisabled";
        print("  " + (char) 175 + " &eStatus: " + status);

        print(" ");
        print("-| &eLoading Staff-Auth");
        if (check("Staff-Auth")) {

        }
        status = check("Staff-Auth") ? "&aEnabled" : "&cDisabled";
        print("  " + (char) 175 + " &eStatus: " + "&bWIP &c(Disabled for now)");

        print(" ");
        print("-| &eLoading Anti-Sign-Glitch");
        if (check("Anti-Sign-Glitch")) {
            getServer().getPluginManager().registerEvents(new AntiSignGlitchHandler(), this);
        }
        status = check("Anti-Sign-Glitch") ? "&aEnabled" : "&cDisabled";
        print("  " + (char) 175 + " &eStatus: " + status);

        print(" ");
        print("&a---------- VyrixSecurity setup complete ----------");
        print(" ");
    }

    public void print(String str) {
        Bukkit.getServer().getConsoleSender().sendMessage(ChatColor.translateAlternateColorCodes('&', str));
    }

    public String boolCompare(boolean val, String trueVal, String falseVal) {
        return val ? trueVal : falseVal;
    }

    public boolean check(String path) {
        return getConfig().getBoolean("Modules." + path + ".Enabled");
    }

    public String colorFromConfig(String str) {
        return ChatColor.translateAlternateColorCodes('&', getConfig().getString(str));
    }
}
