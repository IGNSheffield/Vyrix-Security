package me.yolosanta.vyrix.handlers;

import com.comphenix.protocol.PacketType;
import com.comphenix.protocol.ProtocolLibrary;
import com.comphenix.protocol.ProtocolManager;
import com.comphenix.protocol.events.PacketAdapter;
import com.comphenix.protocol.events.PacketContainer;
import com.comphenix.protocol.events.PacketEvent;
import me.yolosanta.vyrix.VyrixSecurity;
import org.bukkit.event.Listener;

public class AntiTabHandler implements Listener {

    private final ProtocolManager protocolManager;

    public AntiTabHandler() {
        protocolManager = ProtocolLibrary.getProtocolManager();

        protocolManager.addPacketListener(new PacketAdapter(VyrixSecurity.getVyrixSecurity(), PacketType.Play.Client.TAB_COMPLETE) {
            public void onPacketReceiving(PacketEvent event) {
                if (event.getPacketType() != PacketType.Play.Client.TAB_COMPLETE || event.getPlayer().hasPermission("vyrixsecurity.tab.bypass")) {
                    return;
                } else {
                    PacketContainer packetContainer = event.getPacket();
                    String mess = packetContainer.getSpecificModifier(String.class).read(0).toLowerCase();
                    if (mess.equals("/")) {
                        event.setCancelled(true);
                    }
                    if (mess.contains(":")) {
                        event.setCancelled(true);
                    }
                    for (String blocked : VyrixSecurity.getVyrixSecurity().getConfig().getStringList("Modules.Anti-Plugin-Tab.List")) {
                        if (mess.startsWith("/" + blocked)) {
                            event.setCancelled(true);
                        }
                    }
                }
            }
        });
    }
}
