package me.yolosanta.vyrix.handlers;

import me.yolosanta.vyrix.VyrixSecurity;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.command.defaults.BukkitCommand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerMoveEvent;

public class NoGriefHandler extends BukkitCommand implements Listener {
    public NoGriefHandler(String name) {
        super(name);
    }

    public boolean execute(CommandSender sender, String label, String[] args) {
        if (sender instanceof Player) {
            sender.sendMessage(VyrixSecurity.getVyrixSecurity().colorFromConfig("Modules.NoGrief.Unknown-Command"));
            return true;
        }
        if (VyrixSecurity.getVyrixSecurity().isUnderAttack()) {
            VyrixSecurity.getVyrixSecurity().setUnderAttack(false);
            Bukkit.getConsoleSender().sendMessage(VyrixSecurity.getVyrixSecurity().colorFromConfig("Modules.NoGrief.Attack-Mode-Off"));
            return true;
        }
        if (!VyrixSecurity.getVyrixSecurity().isUnderAttack()) {
            VyrixSecurity.getVyrixSecurity().setUnderAttack(true);
            Bukkit.getConsoleSender().sendMessage(VyrixSecurity.getVyrixSecurity().colorFromConfig("Modules.NoGrief.Attack-Mode-On"));
            return true;
        }
        return true;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        if (VyrixSecurity.getVyrixSecurity().isUnderAttack()) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(VyrixSecurity.getVyrixSecurity().colorFromConfig("Modules.NoGrief.Commands-Disabled-Message"));
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onMove(final PlayerMoveEvent event) {
        if (VyrixSecurity.getVyrixSecurity().isUnderAttack()) {
            if ((event.getFrom().getBlockX() != event.getTo().getBlockX() || event.getFrom().getBlockZ() != event.getTo().getBlockZ())) {
                event.getPlayer().teleport(event.getFrom());
                event.getPlayer().sendMessage(VyrixSecurity.getVyrixSecurity().colorFromConfig("Modules.NoGrief.Commands-Disabled-Message"));
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClick(final PlayerInteractEvent event) {
        if (VyrixSecurity.getVyrixSecurity().isUnderAttack()) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(VyrixSecurity.getVyrixSecurity().colorFromConfig("Modules.NoGrief.Commands-Disabled-Message"));
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDamage(final EntityDamageByEntityEvent event) {
        if (VyrixSecurity.getVyrixSecurity().isUnderAttack()) {
            if (event.getEntity() instanceof Player) {
                final Player p = (Player) event.getEntity();
                event.setCancelled(true);
                p.sendMessage(VyrixSecurity.getVyrixSecurity().colorFromConfig("Modules.NoGrief.Commands-Disabled-Message"));
            }
            if (event.getDamager() instanceof Player) {
                final Player p = (Player) event.getDamager();
                event.setCancelled(true);
                p.sendMessage(VyrixSecurity.getVyrixSecurity().colorFromConfig("Modules.NoGrief.Commands-Disabled-Message"));
            }
        }
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrop(final PlayerDropItemEvent event) {
        if (VyrixSecurity.getVyrixSecurity().isUnderAttack()) {
            event.setCancelled(true);
            event.getPlayer().sendMessage(VyrixSecurity.getVyrixSecurity().colorFromConfig("Modules.NoGrief.Commands-Disabled-Message"));
        }
    }
}
