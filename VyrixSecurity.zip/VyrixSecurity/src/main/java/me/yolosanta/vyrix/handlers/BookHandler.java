package me.yolosanta.vyrix.handlers;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerEditBookEvent;

public class BookHandler implements Listener {

    @EventHandler
    public void onEdit(PlayerEditBookEvent event) {
        event.setCancelled(true);
    }
}
