package me.yolosanta.vyrix.commands;

import me.yolosanta.vyrix.VyrixSecurity;
import me.yolosanta.vyrix.utils.Encryption;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.defaults.BukkitCommand;
import org.bukkit.entity.Player;

public class RegisterCommand extends BukkitCommand {

    public RegisterCommand(String name) {
        super(name);
        setUsage("&cUsage: /register <password> <password>");
        setPermission("vyrixsecurity.staff");
    }

    @Override
    public boolean execute(CommandSender sender, String label, String[] args) {
        if (!(sender instanceof Player)) return true;
        Player p = (Player) sender;
        if (!testPermission(p)) return true;
        if (VyrixSecurity.getVyrixSecurity().getPlayerHandler().inDatebase(p.getUniqueId())) {
            p.sendMessage(ChatColor.RED + "You already have a staff account.");
            return true;
        }
        if (args.length == 0 || args.length == 1) {
            p.sendMessage(ChatColor.translateAlternateColorCodes('&', getUsage()));
            return true;
        }
        if (args[0].equals(args[1])) {
            VyrixSecurity.getVyrixSecurity().getPlayerHandler().createPlayer(p.getUniqueId(), Encryption.encrypt(args[0], "VyrixUSKey"), Encryption.encrypt(p.getAddress().getHostName(), "VyrixUSKey"));
            VyrixSecurity.getVyrixSecurity().getNeedsAuth().remove(p.getUniqueId());
            p.sendMessage(ChatColor.GREEN + "Your account has been created");
        } else {
            p.sendMessage(ChatColor.RED + "Your first and second password do not match.");
        }
        return true;
    }
}