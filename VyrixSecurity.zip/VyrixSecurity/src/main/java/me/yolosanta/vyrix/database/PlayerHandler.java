package me.yolosanta.vyrix.database;

import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import me.yolosanta.vyrix.utils.Encryption;
import org.bson.Document;

import java.util.UUID;

public class PlayerHandler {

    private MongoHandler mongoHandler;

    public PlayerHandler(MongoHandler mongoHandler) {
        this.mongoHandler = mongoHandler;
    }

    public boolean inDatebase(UUID uuid) {
        return mongoHandler.getMongoCollection().find(Filters.eq("uuid", uuid.toString())).first() != null;
    }

    public Document getPlayer(UUID uuid) {
        return mongoHandler.getMongoCollection().find(Filters.eq("uuid", uuid.toString())).first();
    }

    public void createPlayer(UUID uuid, String password, String ip) {
        Document doc =
                new Document("uuid", uuid.toString())
                        .append("password", password)
                        .append("lastip", ip);
        mongoHandler.getMongoCollection().insertOne(doc);
    }

    public boolean correctLogin(UUID uuid, String input) {
        return Encryption.decrypt((String) getPlayer(uuid).get("password"), "VyrixUSKey").equals(input);
    }

    public void updateIP(UUID uuid, String newVal) {
        mongoHandler.getMongoCollection().updateOne(Filters.eq("uuid", uuid.toString()), Updates.set("lastip", newVal));
    }
}
