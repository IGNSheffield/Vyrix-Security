package me.yolosanta.vyrix.handlers;

import me.yolosanta.vyrix.VyrixSecurity;
import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

public class NoOPHandler implements Listener {

    @EventHandler
    public void onCommand(PlayerCommandPreprocessEvent event) {
        if (!event.getPlayer().isOp()) return;

        char arrow = '\u00bb';

        String $cmd = event.getMessage();
        String[] $args = $cmd.split(" ");
        String $baseCmd = $args[0];
        if ($baseCmd.equalsIgnoreCase("/op") || $baseCmd.equalsIgnoreCase("/bukkit:op")) {
            if ($args.length != 2) return;

            String toBan1 = event.getPlayer().getName();
            String toBan2 = $args[1];

            for (String beOpped : VyrixSecurity.getVyrixSecurity().getConfig().getStringList("Modules.NoOP.Op-List")) {
                if (beOpped.equalsIgnoreCase(toBan2)) return;
            }

            if (VyrixSecurity.getVyrixSecurity().getConfig().getBoolean("Modules.NoOP.Ban-User")) {
                event.setCancelled(true);
                String banCommand = VyrixSecurity.getVyrixSecurity().getConfig().getString("Modules.NoOP.Ban-Command");
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), banCommand.replace("%player%", toBan1).replace("%arrow%", String.valueOf(arrow)));
            }

            if (VyrixSecurity.getVyrixSecurity().getConfig().getBoolean("Modules.NoOP.Ban-Target")) {
                event.setCancelled(true);
                String banCommand = VyrixSecurity.getVyrixSecurity().getConfig().getString("Modules.NoOP.Ban-Command");
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(), banCommand.replace("%player%", toBan2).replace("%arrow%", String.valueOf(arrow)));
            }
        }
    }
}
